function clearData() {
    document.getElementById('gainchart').innerHTML = "";
    document.getElementById('outputTable').innerHTML = "";
    document.getElementById('analysis').innerHTML = "";
    document.getElementById('clear').innerHTML="";
}